let customerTable= new Array();
let itemTable= new Array();
let orderTable= new Array();
